#!/system/bin/sh
(/data/adb/vr25/djs/djs.sh) &
exit 0

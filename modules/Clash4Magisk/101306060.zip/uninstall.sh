rm_clash() {
  rm -rf /data/adb/clash
}

rm_clash
rm -f /data/adb/service.d/clash_service.sh

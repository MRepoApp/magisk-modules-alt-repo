MODDIR=${0%/*}
. $MODDIR/util_functions.sh

press_check && disable_modules

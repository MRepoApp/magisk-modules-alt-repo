## Changelog

**2024-06-15**: v3.45.3 (_20240615_)

- Updated to SQLite v3.46.0.

**2024-04-18**: v3.45.3 (_20240418_)

- Updated to SQLite v3.45.3.

**2024-03-14**: v3.45.2 (_20240314_)

- Updated to SQLite v3.45.2.

**2024-02-04**: v3.45.1 (_20240204_)

- Updated to SQLite v3.45.1.

**2024-01-16**: v3.45.0 (_20240116_)

- Updated to SQLite v3.45.0.

**2023-12-29**: v3.44.2 (_20231229_)

- Multi-arch support.
- Version scheme was changed.

**2023-12-08**: v3.44.2

- Updated to SQLite v3.44.2.

**2023-10-09**: v3.43.1

- Updated to SQLite 3.43.1.

**2023-08-28**: v3.43.0

- Updated to SQLite 3.43.0.

**2023-08-24**: v3.42.0

- Updated to SQLite 3.42.0.
- Version scheme was changed.

**2022-11-17**: v3.40.0 (_v1.6_)

- Updated to SQLite 3.40.0.

**2021-07-26**: v3.36.0 (_v1.5_)

- Updated to SQLite 3.36.0.

**2021-04-25**: v3.35.5 (_v1.4_)

- Updated to SQLite 3.35.5.
- Updated for Magisk v20.4 template format.

**2019-03-29**: v3.27.2 (_v1.3_)

- Updated to SQLite 3.27.2.

**2019-03-29**: v3.24.0 (_v1.2_)

- Updated for Magisk v19 template format.

**2018-07-22**: v3.24.0 (_v1.1_)

- Now installed in `/system/bin` if `/system/xbin` unavailable.

**2018-07-03**: v3.24.0 (_v1.0_)

- Initial release.
- SQLite 3.24.0.

#!/system/bin/sh
MODDIR=${0%/*}
# Selinux Changer
setenforce
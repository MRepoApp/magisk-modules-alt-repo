# Selinux Changer Module

**Credits**
* By : [@alicee98 aka Yudha](https://t.me/yudhased)
* Support Channel : [GTW Project](https://t.me/gtwprjkt)
* Changelog With Feature List : [Here](https://github.com/Magisk-Modules-Alt-Repo/selinux_mode/main/changelog.md)

**Warning !!**
* Before Change Your Selinux Mode, Please Read This Warning Message!
* Permissive Selinux Maybe Will Make Your Banking App Cant Opened. and Make Your Game Account Got 3rd Party Banned.
* Do With Your Risk!
* Immediately Uninstall This Module If You Don't Want Problems To Happen!

## Changelog
* Selinux Changer Mode By Yudha
* Worked For Audio Mod Like Dolby Atmos Or ViperFX
* With 2 Mode Selinux Changer
* Change Your Selinux Mode.
* Included UpdateJson For Magisk 24+ Version
* Installation With Volume Key. Up For Select, Down For Enter. Notes : It Will Different In Some Device!

**V1**
* First Realease And Published

**V2**
* Fix Some Bugs And Added Warning Text
* Change The Methode From system.prop To post-fs-data.sh

**2.5.1**
* Remove Magisk Log Remover
* Update The Host To Latest Version

**2.5.2**
* Remove Cache Cleaner Because Not the Main Function of This Module
* Maybe There Will Be Many Update Versions To Come, Because This Module Need More Fix.

**2.6**
* Compressed The Size Of Zip
* Removed Some Files

**2.6.1**
* Fix Problem When You Want Update This Module From MagiskApp

**2.6.2**
* Fix Update.

**Telegram Channel Text**
* Changelog Text : [Here](https://t.me/gtwprjkt/6)

**Warning !!**
* Before Change Your Selinux Mode, Please Read This Warning Message!
* Permissive Selinux Maybe Will Make Your Banking App Cant Opened. and Make Your Game Account Got 3rd Party Banned.
* Do With Your Risk!
* Immediately Uninstall This Module If You Don't Want Problems To Happen!

## Registro de cambios:

-1.0
	Versión Inicial.
	
---

*ENGLISH VERSION*

---

## Changelog:

-1.0
    Initial version.

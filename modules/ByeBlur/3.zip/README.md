# Bye Blur

## Description
Disable the blur effect, this improves performance by discarding this complex visual effect.

## Support
- [GitHub](https://github.com/LeanxModulostk/Bye-Blur) 
- [Telegram Channel](https://t.me/modulostk)

## Special Thanks

• [Thanks to @nonosvaimos](https://t.me/nonosvaimos)    

• [Zackptg5 for the MMT-Ex template](https://github.com/Zackptg5)

• [Topjohnwu for making Magisk](https://github.com/topjohnwu)

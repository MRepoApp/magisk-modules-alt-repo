# Saturation
A simple boot script to set the saturation of the panel to 2x.

## Change logs

# v1.0.1
* Added settings for Hires. tracks commented out in "service.sh" for those who like Hires. tracks even on "cheapie" devices anyhow

# v1.0.0
* Initial Release

##
